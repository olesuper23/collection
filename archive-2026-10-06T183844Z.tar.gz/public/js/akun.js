const supabaseClient = window.supabaseClient;
const message = document.getElementById("accountMessage");

document.getElementById("registerForm").addEventListener("submit", async event => {
  event.preventDefault();

  const form = new FormData(event.currentTarget);
  const fullName = form.get("full_name").trim();
  const email = form.get("email").trim();
  const password = form.get("password");

  message.textContent = "Mendaftarkan akun...";

  const { data, error } = await supabaseClient.auth.signUp({
    email,
    password,
    options: {
      data: { full_name: fullName }
    }
  });

  if (error) {
    message.textContent = error.message;
    return;
  }

  message.textContent = data.session
    ? "Akun berhasil dibuat. Silakan masuk."
    : "Pendaftaran berhasil. Periksa email untuk konfirmasi, lalu masuk.";
});

document.getElementById("loginForm").addEventListener("submit", async event => {
  event.preventDefault();

  const form = new FormData(event.currentTarget);
  const email = form.get("email").trim();
  const password = form.get("password");

  message.textContent = "Memeriksa akun...";

  const { data, error } = await supabaseClient.auth.signInWithPassword({
    email,
    password
  });

  if (error) {
    message.textContent = error.message;
    return;
  }

  const { data: profile, error: profileError } = await supabaseClient
    .from("profiles")
    .select("role")
    .eq("id", data.user.id)
    .single();

  if (profileError) {
    message.textContent = "Berhasil masuk, tetapi profil akun belum ditemukan.";
    return;
  }

  if (profile.role === "admin") {
    message.textContent = "Berhasil masuk sebagai admin. Berikutnya kita sambungkan panel admin.";
  } else {
    message.textContent = "Berhasil masuk sebagai pelanggan.";
  }
});
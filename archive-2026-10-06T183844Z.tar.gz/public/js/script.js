// Ganti dengan nomor WhatsApp tokomu.
// Gunakan kode negara tanpa tanda "+".
// Contoh: 628123456789
const WHATSAPP_NUMBER = "62895602749955";

const GRATIS_ONGKIR_MINIMUM = 50000;
const ONGKIR = 10000;

const products = [
  {
    id: 1,
    name: "Anting Solenne",
    category: "Anting",
    price: 25000,
    oldPrice: null,
    badge: "Favorit",
    image: "images/bulujembut.png",
    description: "Anting anggun yang mudah dipadukan untuk menemani hari-hari istimewamu."
  },
  {
    id: 2,
    name: "Kalung Étoile",
    category: "Kalung",
    price: 129000,
    oldPrice: null,
    badge: "Baru",
    image: "images/test.jpg",
    description: "Kalung minimalis dengan sentuhan elegan, cantik dikenakan sendiri maupun ditumpuk."
  },
  {
    id: 3,
    name: "Gelang Amara",
    category: "Gelang",
    price: 99000,
    oldPrice: null,
    badge: "",
    image: "images/gelang-amara.jpg",
    description: "Gelang simpel untuk sentuhan manis yang nyaman dipakai sepanjang hari."
  },
  {
    id: 4,
    name: "Cincin Lune",
    category: "Cincin",
    price: 79000,
    oldPrice: null,
    badge: "Pilihan",
    image: "images/cincin-lune.jpg",
    description: "Cincin manis dengan tampilan timeless untuk melengkapi gaya personalmu."
  }
];

const categories = ["Semua", "Anting", "Kalung", "Gelang", "Cincin"];

let selectedCategory = "Semua";
let favoritesOnly = false;
let activeModalProduct = null;
let toastTimer;

function getSavedData(key, fallback) {
  try {
    const saved = localStorage.getItem(key);
    return saved ? JSON.parse(saved) : fallback;
  } catch {
    return fallback;
  }
}

let cart = getSavedData("sania-cart", {});
let favorites = getSavedData("sania-favorites", []);

function formatRupiah(amount) {
  return new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
    maximumFractionDigits: 0
  }).format(amount);
}

function saveData() {
  localStorage.setItem("sania-cart", JSON.stringify(cart));
  localStorage.setItem("sania-favorites", JSON.stringify(favorites));
}

function renderFilters() {
  const filterContainer = document.getElementById("categoryFilters");

  filterContainer.innerHTML = categories.map(category => `
    <button
      class="filter-button ${selectedCategory === category ? "active" : ""}"
      data-category="${category}"
      type="button"
    >
      ${category}
    </button>
  `).join("");
}

function getVisibleProducts() {
  const searchText = document.getElementById("searchInput").value.trim().toLowerCase();
  const sortType = document.getElementById("sortSelect").value;

  let result = products.filter(product => {
    const matchesCategory =
      selectedCategory === "Semua" || product.category === selectedCategory;

    const matchesSearch =
      `${product.name} ${product.category}`.toLowerCase().includes(searchText);

    const matchesFavorite =
      !favoritesOnly || favorites.includes(product.id);

    return matchesCategory && matchesSearch && matchesFavorite;
  });

  if (sortType === "low") result.sort((a, b) => a.price - b.price);
  if (sortType === "high") result.sort((a, b) => b.price - a.price);
  if (sortType === "name") result.sort((a, b) => a.name.localeCompare(b.name));

  return result;
}

function renderProducts() {
  const grid = document.getElementById("productGrid");
  const visibleProducts = getVisibleProducts();

  if (visibleProducts.length === 0) {
  grid.innerHTML = '<p class="no-results">Produk tidak ditemukan.</p>';
  return;
}

grid.innerHTML = visibleProducts.map(product => `
  <article class="product-card">
    <div class="product-image-wrap">
      <div
        class="product-image"
        role="img"
        aria-label="${product.name}"
        style="
        background-image: url('${product.image}');
        background-size: cover !important;
        background-position: center !important;
        background-repeat: no-repeat !important;
        transform: none !important;
        "
      ></div>

      ${product.badge
        ? `<span class="product-badge">${product.badge}</span>`
        : ""}

      <button
        class="favorite-button ${favorites.includes(product.id) ? "active" : ""}"
        data-favorite="${product.id}"
        type="button"
        aria-label="Tambah ${product.name} ke favorit"
      >
        <svg viewBox="0 0 24 24"
             fill="${favorites.includes(product.id) ? "currentColor" : "none"}"
             stroke="currentColor"
             stroke-width="1.7">
          <path d="M20.8 8.8c0 4.1-8.8 10-8.8 10s-8.8-5.9-8.8-10A4.8 4.8 0 0 1 12 6.7a4.8 4.8 0 0 1 8.8 2.1Z"/>
        </svg>
      </button>

      <button
        class="quick-view"
        data-detail="${product.id}"
        type="button"
      >
        LIHAT DETAIL
      </button>
    </div>

    <div class="product-info">
      <p class="product-category">${product.category}</p>
      <h3 class="product-name">${product.name}</h3>

      <div class="product-price">
        ${formatRupiah(product.price)}
        ${product.oldPrice
          ? `<span class="old-price">${formatRupiah(product.oldPrice)}</span>`
          : ""}
      </div>

      <button
        class="add-to-cart"
        data-add="${product.id}"
        type="button"
      >
        Tambah ke keranjang
      </button>
    </div>
  </article>
`).join("");
}

function renderCart() {
  const cartItems = document.getElementById("cartItems");
  const entries = Object.entries(cart).filter(([, quantity]) => quantity > 0);
  const itemCount = entries.reduce((total, [, quantity]) => total + quantity, 0);

  const subtotal = entries.reduce((total, [id, quantity]) => {
    const product = products.find(item => item.id === Number(id));
    return total + (product ? product.price * quantity : 0);
  }, 0);

  const shipping =
    subtotal === 0 || subtotal >= GRATIS_ONGKIR_MINIMUM ? 0 : ONGKIR;

  document.getElementById("cartCount").textContent = itemCount;
  document.getElementById("subtotal").textContent = formatRupiah(subtotal);
  document.getElementById("shippingCost").textContent =
    subtotal > 0 && shipping === 0 ? "Gratis" : formatRupiah(shipping);
  document.getElementById("grandTotal").textContent =
    formatRupiah(subtotal + shipping);

  document.getElementById("shippingNote").textContent =
    subtotal === 0
      ? "Gratis ongkir untuk belanja minimal Rp50.000."
      : subtotal >= GRATIS_ONGKIR_MINIMUM
        ? "Yeay, pesananmu mendapat gratis ongkir!"
        : `Tambah ${formatRupiah(GRATIS_ONGKIR_MINIMUM - subtotal)} lagi untuk gratis ongkir.`;

  if (entries.length === 0) {
    cartItems.innerHTML = '<p class="empty-cart">Keranjangmu masih kosong.</p>';
  } else {
    cartItems.innerHTML = entries.map(([id, quantity]) => {
      const product = products.find(item => item.id === Number(id));
      if (!product) return "";

      return `
  <div class="cart-row">
    <div
      class="cart-product-image"
      role="img"
      aria-label="${product.name}"
      style="
        background-image: url('${product.image}');
        background-size: cover !important;
        background-position: center !important;
        background-repeat: no-repeat !important;
        transform: none !important;
        "
    ></div>

    <div>
      <h3>${product.name}</h3>
      <div class="cart-row-price">${formatRupiah(product.price)}</div>

      <div class="quantity-control">
        <button data-change="-1" data-id="${id}" type="button">−</button>
        <span>${quantity}</span>
        <button data-change="1" data-id="${id}" type="button">+</button>
      </div>
    </div>

    <button
      class="remove-item"
      data-remove="${id}"
      type="button"
      aria-label="Hapus produk"
    >×</button>
  </div>
`;
    }).join("");
  }

  document.getElementById("checkoutButton").disabled = itemCount === 0;
  saveData();
}

function showToast(message) {
  const toast = document.getElementById("toast");
  toast.textContent = message;
  toast.classList.add("show");

  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2200);
}

function addToCart(id) {
  cart[id] = (cart[id] || 0) + 1;
  renderCart();
  showToast("Produk ditambahkan ke keranjang");
}

function openCart() {
  document.getElementById("cartOverlay").classList.add("open");
  document.body.classList.add("locked");
}

function closeCart() {
  document.getElementById("cartOverlay").classList.remove("open");
  document.body.classList.remove("locked");
}

function openProductDetail(id) {
  const product = products.find(item => item.id === id);
  if (!product) return;

  activeModalProduct = product;

  const modalImage = document.getElementById("modalImage");

modalImage.style.backgroundImage = `url("${product.image}")`;
modalImage.style.setProperty("background-size", "cover", "important");
modalImage.style.setProperty("background-position", "center", "important");
modalImage.style.setProperty("background-repeat", "no-repeat", "important");
modalImage.setAttribute("aria-label", product.name);

  document.getElementById("modalCategory").textContent = product.category;
  document.getElementById("modalName").textContent = product.name;
  document.getElementById("modalPrice").textContent = formatRupiah(product.price);
  document.getElementById("modalDescription").textContent = product.description;

  document.getElementById("productModal").classList.add("open");
  document.body.classList.add("locked");
}

function closeProductDetail() {
  document.getElementById("productModal").classList.remove("open");
  document.body.classList.remove("locked");
}

document.getElementById("categoryFilters").addEventListener("click", event => {
  const button = event.target.closest("[data-category]");
  if (!button) return;

  selectedCategory = button.dataset.category;
  favoritesOnly = false;
  renderFilters();
  renderProducts();
});

document.getElementById("productGrid").addEventListener("click", event => {
  const addButton = event.target.closest("[data-add]");
  const favoriteButton = event.target.closest("[data-favorite]");
  const detailButton = event.target.closest("[data-detail]");

  if (addButton) addToCart(Number(addButton.dataset.add));

  if (favoriteButton) {
    const id = Number(favoriteButton.dataset.favorite);
    favorites = favorites.includes(id)
      ? favorites.filter(item => item !== id)
      : [...favorites, id];

    saveData();
    renderProducts();
  }

  if (detailButton) openProductDetail(Number(detailButton.dataset.detail));
});

document.getElementById("cartItems").addEventListener("click", event => {
  const quantityButton = event.target.closest("[data-change]");
  const removeButton = event.target.closest("[data-remove]");

  if (quantityButton) {
    const id = quantityButton.dataset.id;
    cart[id] = (cart[id] || 0) + Number(quantityButton.dataset.change);

    if (cart[id] <= 0) delete cart[id];
    renderCart();
  }

  if (removeButton) {
    delete cart[removeButton.dataset.remove];
    renderCart();
  }
});

document.getElementById("searchInput").addEventListener("input", renderProducts);
document.getElementById("sortSelect").addEventListener("change", renderProducts);
document.getElementById("openCart").addEventListener("click", openCart);
document.getElementById("closeCart").addEventListener("click", closeCart);

document.getElementById("cartOverlay").addEventListener("click", event => {
  if (event.target.id === "cartOverlay") closeCart();
});

document.getElementById("favoritesButton").addEventListener("click", () => {
  favoritesOnly = !favoritesOnly;
  selectedCategory = "Semua";
  renderFilters();
  renderProducts();
  document.getElementById("koleksi").scrollIntoView({ behavior: "smooth" });
});

document.getElementById("closeModal").addEventListener("click", closeProductDetail);

document.getElementById("productModal").addEventListener("click", event => {
  if (event.target.id === "productModal") closeProductDetail();
});

document.getElementById("modalAddButton").addEventListener("click", () => {
  if (activeModalProduct) addToCart(activeModalProduct.id);
  closeProductDetail();
});

document.getElementById("checkoutButton").addEventListener("click", () => {
  const entries = Object.entries(cart).filter(([, quantity]) => quantity > 0);
  if (entries.length === 0) return;

  const subtotal = entries.reduce((total, [id, quantity]) => {
    const product = products.find(item => item.id === Number(id));
    return total + product.price * quantity;
  }, 0);

  const shipping =
    subtotal === 0 || subtotal >= GRATIS_ONGKIR_MINIMUM ? 0 : ONGKIR;

  const orderLines = entries.map(([id, quantity]) => {
    const product = products.find(item => item.id === Number(id));
    return `- ${product.name} x${quantity}: ${formatRupiah(product.price * quantity)}`;
  });

  const message = [
    "Halo ka, saya ingin pesan:",
    "",
    ...orderLines,
    "",
    `Subtotal: ${formatRupiah(subtotal)}`,
    `Ongkir: ${shipping === 0 ? "Gratis" : formatRupiah(shipping)}`,
    `Total: ${formatRupiah(subtotal + shipping)}`
  ].join("\n");

  window.open(
    `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`,
    "_blank"
  );
});

document.getElementById("footerWhatsapp").href =
  `https://wa.me/${WHATSAPP_NUMBER}`;

document.getElementById("newsletterForm").addEventListener("submit", event => {
  event.preventDefault();
  document.getElementById("newsletterMessage").textContent =
    "Terima kasih! Form email ini masih berupa demo.";
  event.target.reset();
});

document.addEventListener("keydown", event => {
  if (event.key === "Escape") {
    closeCart();
    closeProductDetail();
  }
});

renderFilters();
renderProducts();
renderCart();
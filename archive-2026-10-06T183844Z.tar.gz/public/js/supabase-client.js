const SUPABASE_URL = "https://suimjxrvchrqajfuovzo.supabase.co";
const SUPABASE_PUBLISHABLE_KEY = "sb_publishable_HtzH2uhi_5JTwLPuBnveqg_wyuVkNbF";

window.supabaseClient = window.supabase.createClient(
  SUPABASE_URL,
  SUPABASE_PUBLISHABLE_KEY
);
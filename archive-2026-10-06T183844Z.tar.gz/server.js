const express = require("express");
const path = require("node:path");

const app = express();
const PORT = Number(
  process.env.SERVER_PORT || process.env.PORT || 3000
);

const publicFolder = path.join(__dirname, "public");

app.use(express.static(publicFolder));

app.get("/health", (request, response) => {
  response.status(200).send("Sania Collection berjalan.");
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Website berjalan pada port ${PORT}`);
});